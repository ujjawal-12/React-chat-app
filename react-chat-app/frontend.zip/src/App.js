import { useEffect, useState } from "react";
import {BrowserRouter,Routes,Route} from 'react-router-dom'
import Chat from "./component/chat";
import Error from "./component/error";
import { Home } from "./component/home";
// import {io} from "socket.io-client"

function App(props) {

//  useEffect(()=>{
//    let socket = io("http://localhost:5000/",{transports:["websocket"]});
//    socket.on("connect",()=>{
//      socket.emit("userinfo",props.name);
//    })
//    socket.on("new",(mss)=>{alert(mss)})
//   },[]);

  return (
    <>
    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Home/>}></Route>
      <Route path="/chat" element={<Chat/>}></Route>
      <Route path="*" element={<Error/>}></Route>
    </Routes>
    </BrowserRouter>
    </>
  );
}

export default App;
