import React, { useEffect, useMemo, useState } from 'react'
import { useLocation } from 'react-router-dom';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import {BsArrowRightCircleFill } from "react-icons/bs";
import {io} from "socket.io-client"
import style from "./chat.module.css"
// const ROOT_CSS = css({
//     height: 600,
//     width: 400
//   });
// problem not updated user join list in stateupdate





let socket;
const Chat = () => {
    const location = useLocation();
    let [recievemessage,setmessage] = useState([]);
    let [sendmsge,setsendmsge] = useState("");
    let [userjoin,setuserjoin] = useState([]);
 
    useEffect(()=>{
    socket = io("http://localhost:5000",{transports:['websocket']});
    socket.on("connect",()=>{
      socket.emit("userinfo",location.state.name);  
    })
    socket.on("new",(mss)=>{
       notify("New user join "+mss);
       userjoin.push(mss)
       console.log(userjoin)
       setuserjoin(userjoin) 
    })
    return ()=>{
      socket.emit("disconnect");
      socket.off();
    }
   },[])
  
   useEffect(()=>{
     socket.on("spreadmessage",({user,message})=>{
      recievemessage.push({user,message})
      setmessage([...recievemessage])
      // console.log(newar)
      // alert(user + message);
     })
   
   },[]);

  //  const newuser = useMemo(()=>{
  //    console.log("callmemo")
  //     return (<h3 className='text-dark'>{userjoin}</h3>)
  //  },[userjoin])

   const callsendmsge = () => {
    socket.emit("mssgefrntend",sendmsge,socket.id)
    setsendmsge("")
   }
   const notify = (info) => toast.info(info, {
    position: "top-right",
    autoClose: 5000,
    hideProgressBar: false,
    closeOnClick: true,
    pauseOnHover: true,
    draggable: true,
    progress: undefined,
    });

  return (
   <div className='container-fluid d-flex justify-content-center align-items-center bg-dark text-light' style={{"height":"100vh"}}>
       <div className='container-sm w-50' style={{"height":"400px"}}>
            <div className='bg-danger d-flex justify-content-between' style={{"height":"18%"}}>
            <p className='text-capitalize h4 pt-4 ps-3  text-dark'>Me - {location.state.name}</p>
            <p className='text-capitalize h4 pt-4 ps-3 me-4'>Global Chat
              {/* <label for="lang" className='text-info'>In chat </label>
              <select name="languages" id="lang" className='bg-secondary border border-dark  ms-3 me-3'>
              {userjoin.map((name,ind)=>{ console.log("hh")
                return <option key={ind} value={name}>{name}</option>
              })}
              </select> */}
            </p>

            </div>
            <div className='bg-light border border-primary d-flex flex-column justify-content-start align-items-start overflow-auto' style={{"height":"64%",}}>
                 { recievemessage.map((item,index) =>{return item.user===location.state.name ? <p key={index} className='bg-black  mt-2 py-2 px-4 rounded-pill text-capitalize ms-auto border border-warning'><span className='text-warning '>{item.user}</span> :- {item.message}</p>:<p key={index} className='bg-black  mt-2 py-2 px-4 rounded-pill text-capitalize me-auto border border-info'><span className='text-info '>{item.user}</span> :- {item.message}</p>})}
            </div>
            <div className='bg-secondary text-center d-flex justify-content-center align-items-center' style={{"height":"18%"}}>
              <div className="input-group w-75 ms-4">
               <input type="text" className="form-control p-2" value={sendmsge} onChange={(e)=>setsendmsge(e.target.value)} placeholder="Message" aria-label="Username"/>
              </div>
              <div className='w-25 h-100 '>
              <button type="button" className="btn btn-success border border-dark fs-3 py-1 px-4 position-relative h-75 w-50 mt-2" onClick={callsendmsge} ><span className={`${style.btnan}  `} ><BsArrowRightCircleFill/></span></button>
              </div>
              <ToastContainer />
       </div>
   </div>
   </div>
  )
}

export default Chat