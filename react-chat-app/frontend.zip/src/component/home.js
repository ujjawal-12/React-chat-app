import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import App from '../App';

export const Home = () => {

   const navigate = useNavigate()
   let [name,setname] = useState("");

   const submit = (e)=>{
    if(name){
        navigate("/chat",{replace:true,state:{"name":name}})
    }
    else{
        alert("empty name");
    }
   }

    return (
        <div className='container-fluid d-flex justify-content-center align-items-center bg-secondary' style={{"height":"100vh"}}>
            <div className='container-md d-flex flex-column justify-content-center align-items-center border border-dark bg-success w-25 h-50'>
                <div className='text-center mb-5'>
                    <p className='h2 border border-warning px-5 py-3'>CHAT ROOM</p>
                </div>
                <div className="form-floating mb-3 text-center">
                 <input type="text" className="form-control bg-dark text-light" autoComplete="off" id="floatingInput" value={name} onChange={(e)=>setname(e.target.value)} placeholder="name@example.com"/>
                 <label for="floatingInput" className='text-light '>Enter your name</label>
                 <button type="button" class="btn btn-primary mt-3 border border-dark px-3" onClick={submit}>Join</button>
                </div>
            </div>
        </div>
    )
}
