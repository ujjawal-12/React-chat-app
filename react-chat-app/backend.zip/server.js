const app = require("express")();
const cors = require("cors");
const {createServer} = require("http");
const { Server } = require("socket.io");
const server = createServer(app);

app.use(cors());
app.get("/home",(req,res)=>{res.send("server listen")});
const io = new Server(server);
let arr=[];
io.on("connection",(socket)=>{

   socket.on("userinfo",(mss)=>{
    arr[socket.id]={"name":mss};
    socket.broadcast.emit("new",arr[socket.id].name);
   });
   socket.on("mssgefrntend",(mss,id)=>{
      const data = {user : arr[id].name , message : mss}
      io.emit("spreadmessage",data);
   })
  
})

server.listen(5000,()=>console.log("server listen at port no 5000"));